function ds=uplus(ds)
% Function takes the unary plus of a dataset
%
% Written by: E. Rietsch: August 18, 2005
% Last updated: December 7, 2006: Generalize for PDF's

ds=uoperation(ds,'+');
